double timercode(int seg, void* data) {



  ttCreateJob("TimerTask");



  return FINISHED; 



}

