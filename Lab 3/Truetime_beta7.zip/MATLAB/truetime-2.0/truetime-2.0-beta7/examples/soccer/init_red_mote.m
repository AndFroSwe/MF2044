

% Red Team
xPos(1) =  0;
xPos(2) =  -10;
xPos(3) =   10;
xPos(4) =  -10;
xPos(5) =  10;

yPos(1) =  26;
yPos(2) =  15;
yPos(3) =  15;
yPos(4) =  -10;
yPos(5) =  -10;

xPos_middle = xPos;
yPos_middle = yPos;

xPos(5) = 5;
yPos(5) = 0;

xPos_init = xPos;
yPos_init = yPos;

%F�rsvarspositioner

xPos_defense(1) =  0;
xPos_defense(2) =  -7;
xPos_defense(3) =   7;
xPos_defense(4) =  -7;
xPos_defense(5) =  7;

yPos_defense(1) =  26;
yPos_defense(2) =  18;
yPos_defense(3) =  18;
yPos_defense(4) =  0;
yPos_defense(5) =  0;


%Attakpositioner

xPos_attac(1) =  0;
xPos_attac(2) =  -10;
xPos_attac(3) =   10;
xPos_attac(4) =  -7;
xPos_attac(5) =  7;

yPos_attac(1) =  26;
yPos_attac(2) =  0;
yPos_attac(3) =  0;
yPos_attac(4) =  -18;
yPos_attac(5) =  -18;
