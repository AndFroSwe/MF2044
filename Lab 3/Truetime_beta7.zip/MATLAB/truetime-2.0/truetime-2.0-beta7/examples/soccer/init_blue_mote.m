% Blue Team
xPos(6) =  0;
xPos(7) =  0;
xPos(8) =  0;
xPos(9) = -10;
xPos(10)=  10;

yPos(6) = -26;
yPos(7) =  -5;
yPos(8) =  10;
yPos(9) = -15;
yPos(10)= -15;


xPos_middle = xPos;
yPos_middle = yPos;

xPos(7) = -5;
yPos(7) = 0;

xPos_init = xPos;
yPos_init = yPos;

%F�rsvarspositioner

xPos_defense(6) =  0;
xPos_defense(7) =  1;
xPos_defense(8) =  1;
xPos_defense(9) =  -5;
xPos_defense(10) =  5;

yPos_defense(6) =  -26;
yPos_defense(7) =  -10;
yPos_defense(8) =  3;
yPos_defense(9) =  -20;
yPos_defense(10) = -20;


%Attakpositioner

xPos_attac(6) =  0;
xPos_attac(7) =  1;
xPos_attac(8) =  1;
xPos_attac(9) =  -10;
xPos_attac(10) =  10;

yPos_attac(6) =  -26;
yPos_attac(7) =  7;
yPos_attac(8) =  18;
yPos_attac(9) =  -7;
yPos_attac(10) = -7;
