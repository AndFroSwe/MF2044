setenv('TTKERNEL', 'C:\Users\Public\Documents\MATLAB\truetime-2.0\truetime-2.0-beta7\kernel');
addpath([getenv('TTKERNEL')]);
addpath([getenv('TTKERNEL'),'/matlab/help']);
 addpath([getenv('TTKERNEL'),'/matlab']);